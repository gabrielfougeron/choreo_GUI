""" Version of pillow_heif """

__version__ = "0.8.0"
